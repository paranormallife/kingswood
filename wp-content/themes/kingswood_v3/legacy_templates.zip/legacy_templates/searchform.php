<!-- Search Form -->

<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
<input type="text" name="s" id="s" placeholder="search:" />
</form>