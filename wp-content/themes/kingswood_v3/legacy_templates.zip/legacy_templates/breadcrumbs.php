<?php if ( is_home() ) {
	
	bloginfo('description'); 
	
} else {

bcn_display(); 

}  

?>